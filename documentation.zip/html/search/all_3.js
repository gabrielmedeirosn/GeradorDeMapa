var searchData=
[
  ['getaltitude_0',['getAltitude',['../class_image.html#a43c5fe1e491bfd6c2e35b63269a962e7',1,'Image']]],
  ['getb_1',['getB',['../class_colors.html#a61ed931cc43114bd0ee0017289f37b5d',1,'Colors']]],
  ['getg_2',['getG',['../class_colors.html#a0504eedf770c1a0192a176313fad9175',1,'Colors']]],
  ['getheight_3',['getHeight',['../class_image.html#aa4e1f064e5e1f3f04ad605408f1ec3af',1,'Image']]],
  ['getpixel_4',['getPixel',['../class_image.html#a79f8354f794f2df670954a379d0ed9df',1,'Image']]],
  ['getr_5',['getR',['../class_colors.html#a61a4290f724fe746daa93bc6b5d1838a',1,'Colors']]],
  ['getwidth_6',['getWidth',['../class_image.html#af2720a072812763395512fc3c8c21362',1,'Image']]]
];
