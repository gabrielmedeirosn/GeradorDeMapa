var struct_paleta =
[
    [ "consultarCor", "struct_paleta.html#a4a778ed1956e676a311ff0031170cdf7", null ],
    [ "cores", "struct_paleta.html#a7b7c5f72b4c6bd46f0d80fb3e9294320", null ],
    [ "quantidade", "struct_paleta.html#a81cd0ae951fe457f7ab7371a6a7af2d8", null ],
    [ "valores", "struct_paleta.html#ab2cebcd739b057d38c162f6254ba67bc", null ]
];