var _p_a_l_e_t_a_8h =
[
    [ "Paleta", "struct_paleta.html", "struct_paleta" ]
];