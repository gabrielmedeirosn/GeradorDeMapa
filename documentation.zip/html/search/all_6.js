var searchData=
[
  ['paleta_0',['Paleta',['../struct_paleta.html',1,'']]],
  ['paleta_2eh_1',['PALETA.h',['../_p_a_l_e_t_a_8h.html',1,'']]]
];
