var searchData=
[
  ['image_0',['Image',['../class_image.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../class_image.html#a05c964ca59502cc32c30e8ab89b5e920',1,'Image::Image(int w, int h)']]]
];
