var searchData=
[
  ['clamp_0',['clamp',['../diamond_square_8cpp.html#a1435491618c75dee97c74281a997527b',1,'diamondSquare.cpp']]],
  ['colors_1',['Colors',['../class_colors.html#a66b92465f29b24aedffc6f1b695a7bba',1,'Colors']]],
  ['consultarcor_2',['consultarCor',['../struct_paleta.html#a4a778ed1956e676a311ff0031170cdf7',1,'Paleta']]]
];
