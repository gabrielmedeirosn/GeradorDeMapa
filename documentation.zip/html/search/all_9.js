var searchData=
[
  ['salvarcomoppm_0',['salvarComoPPM',['../class_image.html#a6eaad028dabd96ef76d2f9e784195039',1,'Image']]],
  ['setaltitude_1',['setAltitude',['../class_image.html#adabea2c45aadc0b0a0d3907f41aa33cc',1,'Image']]],
  ['setb_2',['setB',['../class_colors.html#a780b2ba8818870af67727bf987b50452',1,'Colors']]],
  ['setg_3',['setG',['../class_colors.html#a466ca05f7f4edff1316c110a0c4b9b61',1,'Colors']]],
  ['setheight_4',['setHeight',['../class_image.html#a18d7835fb7f6d6f15c8e98b80aa769cc',1,'Image']]],
  ['setpixel_5',['setPixel',['../class_image.html#a3020fed540a9e2c3d2741b3092636b24',1,'Image']]],
  ['setr_6',['setR',['../class_colors.html#a1c514a4850f55c79e4de813295a983f5',1,'Colors']]],
  ['setwidth_7',['setWidth',['../class_image.html#a62503e68a79d2e783708a2f487532103',1,'Image']]]
];
