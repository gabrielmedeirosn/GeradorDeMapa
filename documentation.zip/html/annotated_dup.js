var annotated_dup =
[
    [ "Colors", "class_colors.html", "class_colors" ],
    [ "Image", "class_image.html", "class_image" ],
    [ "Paleta", "struct_paleta.html", "struct_paleta" ]
];