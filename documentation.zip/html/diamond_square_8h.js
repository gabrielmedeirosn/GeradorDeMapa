var diamond_square_8h =
[
    [ "diamondSquare", "diamond_square_8h.html#af832fdcab30845ecee5c24d2473eb4ad", null ]
];