var searchData=
[
  ['clamp_0',['clamp',['../diamond_square_8cpp.html#a1435491618c75dee97c74281a997527b',1,'diamondSquare.cpp']]],
  ['colors_1',['Colors',['../class_colors.html',1,'Colors'],['../class_colors.html#a66b92465f29b24aedffc6f1b695a7bba',1,'Colors::Colors()']]],
  ['consultarcor_2',['consultarCor',['../struct_paleta.html#a4a778ed1956e676a311ff0031170cdf7',1,'Paleta']]],
  ['cor_2ecpp_3',['COR.cpp',['../_c_o_r_8cpp.html',1,'']]],
  ['cor_2eh_4',['COR.h',['../_c_o_r_8h.html',1,'']]],
  ['cores_5',['cores',['../struct_paleta.html#a7b7c5f72b4c6bd46f0d80fb3e9294320',1,'Paleta']]]
];
