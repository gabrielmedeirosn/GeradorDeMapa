var class_colors =
[
    [ "Colors", "class_colors.html#a66b92465f29b24aedffc6f1b695a7bba", null ],
    [ "~Colors", "class_colors.html#a67a925c318af85c5ae979c2178124466", null ],
    [ "escurece", "class_colors.html#ae9483be78b08a8d68002550e64786a3a", null ],
    [ "getB", "class_colors.html#a61ed931cc43114bd0ee0017289f37b5d", null ],
    [ "getG", "class_colors.html#a0504eedf770c1a0192a176313fad9175", null ],
    [ "getR", "class_colors.html#a61a4290f724fe746daa93bc6b5d1838a", null ],
    [ "setB", "class_colors.html#a780b2ba8818870af67727bf987b50452", null ],
    [ "setG", "class_colors.html#a466ca05f7f4edff1316c110a0c4b9b61", null ],
    [ "setR", "class_colors.html#a1c514a4850f55c79e4de813295a983f5", null ]
];