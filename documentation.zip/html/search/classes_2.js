var searchData=
[
  ['paleta_0',['Paleta',['../struct_paleta.html',1,'']]]
];
