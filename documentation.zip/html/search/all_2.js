var searchData=
[
  ['escurece_0',['escurece',['../class_colors.html#ae9483be78b08a8d68002550e64786a3a',1,'Colors']]]
];
