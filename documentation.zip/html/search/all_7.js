var searchData=
[
  ['quantidade_0',['quantidade',['../struct_paleta.html#a81cd0ae951fe457f7ab7371a6a7af2d8',1,'Paleta']]]
];
