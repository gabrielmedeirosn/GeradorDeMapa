var files_dup =
[
    [ "COR.cpp", "_c_o_r_8cpp.html", null ],
    [ "COR.h", "_c_o_r_8h.html", "_c_o_r_8h" ],
    [ "diamondSquare.cpp", "diamond_square_8cpp.html", "diamond_square_8cpp" ],
    [ "diamondSquare.h", "diamond_square_8h.html", "diamond_square_8h" ],
    [ "IMG.cpp", "_i_m_g_8cpp.html", null ],
    [ "IMG.h", "_i_m_g_8h.html", "_i_m_g_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "PALETA.h", "_p_a_l_e_t_a_8h.html", "_p_a_l_e_t_a_8h" ]
];