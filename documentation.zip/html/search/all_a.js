var searchData=
[
  ['valores_0',['valores',['../struct_paleta.html#ab2cebcd739b057d38c162f6254ba67bc',1,'Paleta']]]
];
