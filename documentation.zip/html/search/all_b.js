var searchData=
[
  ['_7ecolors_0',['~Colors',['../class_colors.html#a67a925c318af85c5ae979c2178124466',1,'Colors']]],
  ['_7eimage_1',['~Image',['../class_image.html#a0294f63700543e11c0f0da85601c7ae5',1,'Image']]]
];
