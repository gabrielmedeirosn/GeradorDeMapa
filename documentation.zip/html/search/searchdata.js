var indexSectionsWithContent =
{
  0: "cdegimpqrsv~",
  1: "cip",
  2: "cdimpr",
  3: "cdegims~",
  4: "cqv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

