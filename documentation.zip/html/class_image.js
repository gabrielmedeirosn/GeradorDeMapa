var class_image =
[
    [ "Image", "class_image.html#a58edd1c45b4faeb5f789b0d036d02313", null ],
    [ "Image", "class_image.html#a05c964ca59502cc32c30e8ab89b5e920", null ],
    [ "~Image", "class_image.html#a0294f63700543e11c0f0da85601c7ae5", null ],
    [ "getAltitude", "class_image.html#a43c5fe1e491bfd6c2e35b63269a962e7", null ],
    [ "getHeight", "class_image.html#aa4e1f064e5e1f3f04ad605408f1ec3af", null ],
    [ "getPixel", "class_image.html#a79f8354f794f2df670954a379d0ed9df", null ],
    [ "getWidth", "class_image.html#af2720a072812763395512fc3c8c21362", null ],
    [ "salvarComoPPM", "class_image.html#a6eaad028dabd96ef76d2f9e784195039", null ],
    [ "setAltitude", "class_image.html#adabea2c45aadc0b0a0d3907f41aa33cc", null ],
    [ "setHeight", "class_image.html#a18d7835fb7f6d6f15c8e98b80aa769cc", null ],
    [ "setPixel", "class_image.html#a3020fed540a9e2c3d2741b3092636b24", null ],
    [ "setWidth", "class_image.html#a62503e68a79d2e783708a2f487532103", null ]
];