var searchData=
[
  ['cores_0',['cores',['../struct_paleta.html#a7b7c5f72b4c6bd46f0d80fb3e9294320',1,'Paleta']]]
];
