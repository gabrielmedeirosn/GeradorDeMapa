var diamond_square_8cpp =
[
    [ "clamp", "diamond_square_8cpp.html#a1435491618c75dee97c74281a997527b", null ],
    [ "diamondSquare", "diamond_square_8cpp.html#ac9bc938d4328167821bbda62d066eeeb", null ]
];