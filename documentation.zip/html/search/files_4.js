var searchData=
[
  ['paleta_2eh_0',['PALETA.h',['../_p_a_l_e_t_a_8h.html',1,'']]]
];
